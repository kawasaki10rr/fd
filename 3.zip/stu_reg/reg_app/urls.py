from django.urls import URLResolver, path
from . import views

urlpatterns = [
    path('',views.home)
]