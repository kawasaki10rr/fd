from django.shortcuts import render, redirect
from .forms import ProjectForm

def project_view(request):
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('success')
    else:
        form = ProjectForm()

    return render(request, 'project_form.html', {'form': form})


def success_view(request):
    return render(request, 'success.html')