from django.urls import path
from .import views
urlpatterns = [
    path('project/', views.project_view, name='project'),
    path('success/', views.success_view, name='success'),
]