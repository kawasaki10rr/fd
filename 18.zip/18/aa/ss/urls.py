from django.urls import path
from .import views 

urlpatterns = [
    path("signup/", views.user_signup, name="user_signup"),
    path("signin/", views.UserSigninView.as_view(), name="user_signin"),
    path("signout/", views.UserSignoutView.as_view(), name="user_signout"),
    path("dashboard/", views.dashboard_view, name="dashboard"),
]