from django.http  import HttpResponse
from datetime import timedelta, datetime

def home(request):
    now = datetime.now()
    ahead = now + timedelta(hours=4)
    before = now - timedelta(hours = 4)

    html = f"""
    <h1> Time Date Offset app </h1>
    <h3> current time : {now} <br>
    time after 4 hours :  {ahead} <br>
    time before 4 hours : {before}
    </h3>
    """

    return HttpResponse(html)

