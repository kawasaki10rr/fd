from django.shortcuts import render

# Create your views here.
from django.views.generic import *
from .models import Student


class StudentList(ListView):

    model = Student


class StudentDetail(DetailView):

    model = Student


class StudentCreate(CreateView):

    model = Student

    fields = ['usn', 'name']

    success_url = '/'


class StudentUpdate(UpdateView):

    model = Student

    fields = ['usn', 'name']

    success_url = '/'


class StudentDelete(DeleteView):

    model = Student

    success_url = '/'