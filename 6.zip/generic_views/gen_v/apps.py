from django.apps import AppConfig


class GenVConfig(AppConfig):
    name = 'gen_v'
