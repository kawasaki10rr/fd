from django.urls import path 
from . import views

urlpatterns = [
    path("time/<int:hours>/", views.time,)
]
