from django.shortcuts import render

from django.http import HttpResponse
from datetime import datetime,timedelta

def time (request, hours):
    now = datetime.now().replace(microsecond=0)
    after = (now+timedelta(hours=hours)).replace(microsecond=0)
    before = (now-timedelta(hours=hours)).replace(microsecond=0)
    
    return HttpResponse(f"""
                        
                        <h3> Results</h3>
                        <hr>
                        Current Time: {now}
                        <br>
                      after {hours } : {after}
                      <br>
                        before {hours }: {before}
                        """)