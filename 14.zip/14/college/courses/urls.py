from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register_student, name='register'),
    path('course-students/', views.course_students, name='course_students'),
    path('csv/<int:course_id>/', views.export_csv),
path('pdf/<int:course_id>/', views.export_pdf),
]