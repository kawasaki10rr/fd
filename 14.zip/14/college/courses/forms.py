from django import forms
from .models import Student, Course

class StudentRegistrationForm(forms.Form):
    student_name = forms.CharField()
    courses = forms.ModelMultipleChoiceField(
        queryset=Course.objects.all(),
        widget=forms.CheckboxSelectMultiple
        )