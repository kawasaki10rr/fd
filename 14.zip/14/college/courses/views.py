from django.shortcuts import render, redirect
from django.http import HttpResponse

from .models import Student, Course
from .forms import StudentRegistrationForm

import csv
from reportlab.pdfgen import canvas


def home(request):
    return HttpResponse("Welcome to Student Course Registration App")


def register_student(request):

    form = StudentRegistrationForm(request.POST or None)

    if request.method == 'POST' and form.is_valid():

        student, created = Student.objects.get_or_create(
            name=form.cleaned_data['student_name']
        )

        for course in form.cleaned_data['courses']:
            student.courses.add(course)

        return redirect('register')

    return render(request, 'register.html', {'form': form})


def course_students(request):

    courses = Course.objects.all()
    students = None
    course = None

    if request.method == 'POST':

        course = Course.objects.get(id=request.POST.get('course'))

        students = course.students.all()

    return render(request, 'course_students.html', {
        'courses': courses,
        'students': students,
        'course': course
    })


# CSV
def export_csv(request, course_id):

    response = HttpResponse(content_type='text/csv')

    writer = csv.writer(response)

    course = Course.objects.get(id=course_id)

    writer.writerow(['Course:', course.name])
    writer.writerow([])
    writer.writerow(['Registered Students'])

    students = course.students.all()

    for student in students:

        writer.writerow([student.name])

    return response


# PDF
def export_pdf(request, course_id):

    response = HttpResponse(content_type='application/pdf')

    p = canvas.Canvas(response)

    course = Course.objects.get(id=course_id)

    p.drawString(100, 800, f"Course: {course.name}")

    p.drawString(100, 770, "Registered Students")

    y = 730

    students = course.students.all()

    for student in students:

        p.drawString(120, y, student.name)

        y -= 30

    p.save()

    return response