from django.apps import AppConfig


class ProjDetailConfig(AppConfig):
    name = 'proj_detail'
