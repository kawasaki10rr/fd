from django.db import models

# Create your models here.
class Project(models.Model):
    sname = models.CharField(max_length=100)
    topic = models.CharField(max_length=100)

    language = models.CharField(max_length=100)
    duration = models.IntegerField()

    def __str__(self):
        return self.sname