from django.shortcuts import render,redirect

# Create your views here.
from .forms import ProjectForm

def home(request):
    form = ProjectForm()

    if request.method == 'POST':
        form = ProjectForm(request.POST)

        if form.is_valid():
            form.save()

            return redirect('/')
    return render(request,'home.html',{'form':form})