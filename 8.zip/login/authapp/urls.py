from django.urls import path
from . import views

urlpatterns = [

    path('register/', views.register),

    path('login/', views.userlogin),

    path('home/', views.home),

    path('logout/', views.userlogout),
]