from django.shortcuts import render, redirect

from django.contrib.auth.models import User

from django.contrib.auth import authenticate, login, logout


def register(request):

    if request.method == 'POST':

        username = request.POST['username']

        password = request.POST['password']

        User.objects.create_user(
            username=username,
            password=password
        )

        return redirect('/login/')

    return render(request, 'register.html')



def userlogin(request):

    if request.method == 'POST':

        username = request.POST['username']

        password = request.POST['password']

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user is not None:

            login(request, user)

            return redirect('/home/')

    return render(request, 'login.html')



def home(request):

    return render(request, 'home.html')



def userlogout(request):

    logout(request)

    return redirect('/login/')