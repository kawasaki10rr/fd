from django.db import models

class Student(models.Model):
    sname = models.CharField(max_length=100)
    usn = models.CharField(max_length=20)

    def __str__(self):
        return self.sname


class Course(models.Model):
    cname = models.CharField(max_length=100)
    ccode = models.CharField(max_length=6)

    enrolment = models.ManyToManyField(Student)

    def __str__(self):
        return self.cname