
from django.urls import path
from . import views

urlpatterns = [
    path('',views.home),
    path('csv/', views.csvfile),

    path('pdf/', views.pdffile),
]