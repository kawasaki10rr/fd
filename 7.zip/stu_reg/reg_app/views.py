from django.shortcuts import render
from .models import Course

def home(request):

    courses = Course.objects.all()

    return render(request, 'home.html', {'courses': courses})


# csv pdf

import csv

from django.http import HttpResponse

from reportlab.pdfgen import canvas

from .models import Student


def csvfile(request):

    response = HttpResponse(content_type='text/csv')

    response['Content-Disposition'] = 'attachment; filename=students.csv'

    writer = csv.writer(response)

    students = Student.objects.all()

    for s in students:

        writer.writerow([s.usn, s.sname])

    return response



def pdffile(request):

    response = HttpResponse(content_type='application/pdf')

    response['Content-Disposition'] = 'attachment; filename=students.pdf'

    p = canvas.Canvas(response)

    p.drawString(100, 800, "Student Details")

    students = Student.objects.all()

    y = 750

    for s in students:

        p.drawString(100, y, s.usn + " " + s.sname)

        y -= 40

    p.save()

    return response